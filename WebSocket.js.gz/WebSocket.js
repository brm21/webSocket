var rainbowEnable = false;
var simonEnable = false;
var randomNumber = Math.floor(Math.random() * 1023);
var connection = new WebSocket('ws://'+location.hostname+':81/', ['arduino']);
connection.onopen = function () {
    connection.send('Connect ' + new Date());
};
connection.onerror = function (error) {
    console.log('WebSocket Error ', error);
};
connection.onmessage = function (e) {  
    console.log('Server: ', e.data);
};
connection.onclose = function(){
    console.log('WebSocket connection closed');
};

function sendRGB() {
    var r = document.getElementById('r').value**2/1023;
    var g = document.getElementById('g').value**2/1023;
    var b = document.getElementById('b').value**2/1023;
    
    var rgb = r << 20 | g << 10 | b;
    var rgbstr = '#'+ rgb.toString(16);    
    console.log('RGB: ' + rgbstr); 
    connection.send(rgbstr);
}

function simon_says(){
    simonEnable = ! simonEnable;
    if(simonEnable){
        connection.send("S");
	document.getElementById('simon').style.backgroundColor = '#00878F';
	document.getElementById('buttonTable').style.display = 'block';
	document.getElementById('pushRed').className = 'enabled button';
	document.getElementById('pushGreen').className = 'enabled button';
	document.getElementById('pushBlue').className = 'enabled button';
	document.getElementById('submit').className = 'enabled button';
        document.getElementById('r').className = 'disabled';
        document.getElementById('g').className = 'disabled';
        document.getElementById('b').className = 'disabled';
	document.getElementById('rm').className = 'disabled button';
        document.getElementById('gm').className = 'disabled button';
        document.getElementById('bm').className = 'disabled button';
        document.getElementById('reset').className = 'disabled button';
        document.getElementById('random').className = 'disabled button';
	document.getElementById('rainbow').className = 'disabled button';
	document.getElementById('r').disabled = true;
        document.getElementById('g').disabled = true;
        document.getElementById('b').disabled = true;
	document.getElementById('rm').disabled = true;
        document.getElementById('gm').disabled = true;
        document.getElementById('bm').disabled = true;
        document.getElementById('reset').disabled = true;
        document.getElementById('random').disabled = true;
	document.getElementById('rainbow').disabled = true;
	document.getElementById('pushRed').disabled = false;
        document.getElementById('pushGreen').disabled = false;
        document.getElementById('pushBlue').disabled = false;
	document.getElementById('submit').disabled = false;	
    } else { 
	connection.send("X");
	document.getElementById('simon').style.backgroundColor = '#999';
	document.getElementById('buttonTable').style.display = 'none';
        document.getElementById('r').className = 'enabled';
        document.getElementById('g').className = 'enabled';
        document.getElementById('b').className = 'enabled';
	document.getElementById('rm').className = 'enabled button';
        document.getElementById('gm').className = 'enabled button';
        document.getElementById('bm').className = 'enabled button';
	document.getElementById('rainbow').className = 'enabled button';
        document.getElementById('reset').className = 'enabled button';
        document.getElementById('random').className = 'enabled button';
        document.getElementById('r').disabled = false;
        document.getElementById('g').disabled = false;
        document.getElementById('b').disabled = false;
	document.getElementById('rm').disabled = false;
        document.getElementById('gm').disabled = false;
        document.getElementById('bm').disabled = false;
        document.getElementById('reset').disabled = false;
        document.getElementById('random').disabled = false;
	document.getElementById('rainbow').disabled = false;
	document.getElementById('pushRed').disabled = true;
        document.getElementById('pushGreen').disabled = true;
        document.getElementById('pushBlue').disabled = true;
	document.getElementById('submit').disabled = true;
        sendRGB();
    }
        
}

function pushRed(){
       console.log('Red Pushed'); 
       connection.send("T");
}

function pushGreen(){
       console.log('Green Pushed');
       connection.send("G");
}

function pushBlue(){
       console.log('Blue Pushed');
       connection.send("B");
}

function submit(){
	console.log('Submit Pushed');
	connection.send("F");
} 

function rainbowEffect(){
    rainbowEnable = ! rainbowEnable;
    if(rainbowEnable){
        connection.send("R");
        document.getElementById('rainbow').style.backgroundColor = '#00878F';
        document.getElementById('r').className = 'disabled';
        document.getElementById('g').className = 'disabled';
        document.getElementById('b').className = 'disabled';
	document.getElementById('rm').className = 'disabled button';
	document.getElementById('gm').className = 'disabled button';
	document.getElementById('bm').className = 'disabled button';
	document.getElementById('reset').className = 'disabled button';
	document.getElementById('random').className = 'disabled button';
	document.getElementById('simon').className = 'disabled button';
        document.getElementById('r').disabled = true;
        document.getElementById('g').disabled = true;
        document.getElementById('b').disabled = true;
	document.getElementById('rm').disabled = true;
	document.getElementById('gm').disabled = true;
	document.getElementById('bm').disabled = true;
	document.getElementById('reset').disabled = true;
	document.getElementById('random').disabled = true;
	document.getElementById('simon').disabled = true;
    } else {
        connection.send("N");
        document.getElementById('rainbow').style.backgroundColor = '#999';
        document.getElementById('r').className = 'enabled';
        document.getElementById('g').className = 'enabled';
        document.getElementById('b').className = 'enabled';
	document.getElementById('rm').className = 'enabled button';
	document.getElementById('gm').className = 'enabled button';
	document.getElementById('bm').className = 'enabled button';
	document.getElementById('reset').className = 'enabled button';
	document.getElementById('random').className = 'enabled button';
	document.getElementById('simon').className = 'enabled button';
        document.getElementById('r').disabled = false;
        document.getElementById('g').disabled = false;
        document.getElementById('b').disabled = false;
	document.getElementById('rm').disabled = false;
	document.getElementById('gm').disabled = false;
	document.getElementById('bm').disabled = false;
	document.getElementById('reset').disabled = false;
	document.getElementById('random').disabled = false;
	document.getElementById('simon').disabled = false;
        sendRGB();
    }  
}

function maxRed(){
    document.getElementById('r').value = 1023;
    sendRGB(); 
}

function maxGreen(){
    document.getElementById('g').value = 1023;
    sendRGB();
}

function maxBlue(){
    document.getElementById('b').value = 1023;
    sendRGB();
}    

function reset(){
    document.getElementById('r').value = 0;
    document.getElementById('g').value = 0;
    document.getElementById('b').value = 0;
    sendRGB();
}

function random(){
    var randomRed = Math.floor(Math.random() * 1023);
    var randomGreen = Math.floor(Math.random() * 1023);
    var randomBlue = Math.floor(Math.random() * 1023);	
    document.getElementById('r').value = randomRed;
    document.getElementById('g').value = randomGreen;
    document.getElementById('b').value = randomBlue;
    sendRGB();
}
    
